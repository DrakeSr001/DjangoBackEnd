from django.apps import AppConfig


class TodosapiConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "todosAPI"
